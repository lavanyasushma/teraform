#!/bin/bash
echo "Updating repository"
sudo dnf update -y
# echo "Finished updating of repository.  Installing tomcat"
# sudo dnf install tomcat tomcat-admin-webapps tomcat-docs-webapp tomcat-el-3.0-api tomcat-jsp-2.3-api tomcat-lib tomcat-servlet-4.0-api tomcat-webapps -y
# sudo systemctl enable tomcat
# sudo systemctl start tomcat

# echo "Install yum utils"
# sudo yum install -y yum-utils
sudo yum-config-manager --add-repo https://rpm.releases.hashicorp.com/RHEL/hashicorp.repo
sudo yum -y install packer

echo "Finished installing yum utils and packer.  Installing Azure CLI"
# sudo rpm --import https://packages.microsoft.com/keys/microsoft.asc
# sudo dnf install -y https://packages.microsoft.com/config/rhel/8/packages-microsoft-prod.rpm
# sudo dnf install azure-cli -y

# echo "Finished Installing azure cli.  Installing git"
sudo dnf install git-all -y

sudo dnf install cifs-utils -y

sudo mkdir -p /tmp/github

sudo git clone 
